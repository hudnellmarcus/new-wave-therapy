import TeamGrid from "../components/TeamGrid";

const TeamPage = () => {
  return (
    <main className="min-h-screen">
      <TeamGrid />
    </main>
  );
};

export default TeamPage;